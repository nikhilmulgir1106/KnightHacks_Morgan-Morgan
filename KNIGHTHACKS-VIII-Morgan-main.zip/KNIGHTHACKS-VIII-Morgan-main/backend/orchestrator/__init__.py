"""
Orchestrator module for KNIGHTHACKS-VIII-Morgan
Handles task detection and agent routing
"""
