"""
Postprocessor modules for KNIGHTHACKS-VIII-Morgan
"""

from . import brief_generator

__all__ = ['brief_generator']
